"""Rust batch wire I/O and typed decoding for the unchanged Lean simulator.

The C call releases the GIL. Python retains process lifecycle, lineage dedup,
and Snapshot objects for the evaluator. Feature data crosses the ABI in one
immutable bytes allocation; NumPy views retain that storage after Rust frees its
batch. No response JSON dictionaries or per-row base64 decoding occur in Python.
"""

from __future__ import annotations

import ctypes as C
from functools import lru_cache

import numpy as np

U = C.c_uint64
P = C.c_void_p


class Span(C.Structure):
    _fields_ = [("offset", U), ("length", U)]


class Row(C.Structure):
    _fields_ = (
        [
            (n, U)
            for n in (
                "handle",
                "player_mask",
                "enemy_mask",
                "turn",
                "terminal",
                "done",
                "has_return",
            )
        ]
        + [("terminal_return", C.c_int64)]
        + [
            (n, U)
            for n in (
                "player_popular",
                "enemy_popular",
                "has_divergence",
                "feature_kind",
            )
        ]
        + [
            (n, Span)
            for n in (
                "player_features",
                "enemy_features",
                "player_hash",
                "enemy_hash",
                "request",
                "divergence",
            )
        ]
    )


class View(C.Structure):
    _fields_ = [
        ("rows", C.POINTER(Row)),
        ("count", C.c_size_t),
        ("features", P),
        ("feature_bytes", C.c_size_t),
        ("text", P),
        ("text_bytes", C.c_size_t),
    ]


@lru_cache(maxsize=1)
def library():
    from .search_native import _library

    lib = _library()
    signatures = {
        "abi": ([], U),
        "batch": (
            [
                C.c_int,
                C.c_int,
                U,
                U,
                P,
                C.c_size_t,
                C.c_size_t,
                C.c_double,
                C.POINTER(P),
            ],
            C.c_int,
        ),
        "decode": ([P, C.c_size_t, U, C.c_size_t, C.c_size_t, C.POINTER(P)], C.c_int),
        "view": ([P, C.POINTER(View)], C.c_int),
        "error": ([P, C.POINTER(C.c_size_t)], P),
        "free": ([P], None),
    }
    try:
        for name, (args, result) in signatures.items():
            fn = getattr(lib, f"battle_transport_{name}_v1")
            fn.argtypes, fn.restype = args, result
        if lib.battle_transport_abi_v1() != 1:
            raise RuntimeError("incompatible Rust simulator transport ABI")
    except AttributeError as error:
        raise RuntimeError(
            "Rust library lacks simulator transport; rebuild battle-search"
        ) from error
    return lib


class TransportTimeout(RuntimeError):
    pass


def unpack(lib, handle, code):
    from .native import Snapshot

    try:
        if code:
            length = C.c_size_t()
            pointer = lib.battle_transport_error_v1(handle, C.byref(length))
            message = (
                C.string_at(pointer, length.value).decode("utf-8")
                if pointer
                else "Rust transport failed"
            )
            raise (TransportTimeout if code == 2 else RuntimeError)(message)
        view = View()
        if lib.battle_transport_view_v1(handle, C.byref(view)):
            raise RuntimeError("invalid Rust transport batch view")
        features = C.string_at(view.features, view.feature_bytes)
        text = C.string_at(view.text, view.text_bytes)

        def string(span):
            return text[span.offset : span.offset + span.length].decode("utf-8")

        snapshots = []
        for i in range(view.count):
            row = view.rows[i]
            dtype = np.dtype("<u2" if row.feature_kind else "<i8")

            def array(span, dtype=dtype):
                return np.frombuffer(
                    features,
                    dtype=dtype,
                    count=span.length // dtype.itemsize,
                    offset=span.offset,
                )

            snapshots.append(
                Snapshot(
                    handle=row.handle,
                    player_features=array(row.player_features),
                    enemy_features=array(row.enemy_features),
                    player_mask=row.player_mask,
                    enemy_mask=row.enemy_mask,
                    player_hash=string(row.player_hash),
                    enemy_hash=string(row.enemy_hash),
                    turn=row.turn,
                    terminal=bool(row.terminal),
                    done=bool(row.done),
                    terminal_return=row.terminal_return if row.has_return else None,
                    request=string(row.request),
                    divergence=string(row.divergence) if row.has_divergence else None,
                    player_popular=bool(row.player_popular),
                    enemy_popular=bool(row.enemy_popular),
                )
            )
        return snapshots
    finally:
        lib.battle_transport_free_v1(handle)


def batch(input_fd, output_fd, request_id, episode, requests, feature_count, timeout):
    lib = library()
    rows = np.asarray(requests, dtype=np.uint64)
    if rows.ndim != 2 or rows.shape[1] != 4:
        raise ValueError("native requests must have four unsigned integers per row")
    rows = np.ascontiguousarray(rows)
    handle = P()
    code = lib.battle_transport_batch_v1(
        input_fd,
        output_fd,
        request_id,
        episode,
        rows.ctypes.data,
        len(rows),
        feature_count,
        timeout,
        C.byref(handle),
    )
    return unpack(lib, handle, code)


def decode(data: bytes, request_id: int, count: int, feature_count: int):
    """Decode-only entrypoint for protocol differential tests and profiling."""
    lib = library()
    handle = P()
    code = lib.battle_transport_decode_v1(
        data, len(data), request_id, count, feature_count, C.byref(handle)
    )
    return unpack(lib, handle, code)
